<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\AuthController;
use App\Models\Project;

/*Route::get('/', function () {
    $project = Project::find(1);
    dd($project->categories);
    return view('index');
});
*/

Route::get('/home', [IndexController::class, 'index'])->name('home');
Route::get('/', [AuthController::class, 'index']);
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/register', [AuthController::class, 'register'])->name('register');