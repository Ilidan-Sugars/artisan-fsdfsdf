<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthController extends Controller
{

    function index()
    {
        return view('login');
    }

    function login(Request $request) 
    {
        //dd($request->all());
        $login = $request->input('login');
        $password = $request->input('password');
        if($login == 'admin' && $password == 'admin') {
            return redirect()->route('home');
        } else {
            return redirect()->route('/');
        }

    }

    function register() 
    {

    }
}
