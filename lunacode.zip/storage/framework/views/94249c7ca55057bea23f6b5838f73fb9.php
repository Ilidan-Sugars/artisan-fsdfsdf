<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Home</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel\home\lunacode\resources\views/index.blade.php ENDPATH**/ ?>