<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('login')); ?>" method="post">
        <input name="login"  type='text' placeholder='Login'>
        <input name="password" type='password' placeholder='Password'>
        <button type='submit'>Signin</button>
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel\home\lunacode\resources\views/login.blade.php ENDPATH**/ ?>